# ![logo](/arifistifik.jpg) LINE Python

 [![Version 3.0.8](https://img.shields.io/badge/beta-3.0.8-brightgreen.svg "Version 3.0.8")](https://pypi.python.org/pypi/linepy) [![LICENSE](https://img.shields.io/badge/license-BSD%203%20Clause-blue.svg "LICENSE")](https://github.com/fadhiilrachman/line-py/blob/master/LICENSE) [![Supported python versions: 3.x](https://img.shields.io/badge/python-3.x-green.svg "Supported python versions: 3.x")](https://www.python.org/downloads/) [![Chat on Discord](https://discordapp.com/api/guilds/370888828489170956/widget.png "Chat on Discord")](https://discord.gg/JAA2uk6)

*LINE Messaging's private API*

----

## Requirement

The linepy module only requires Python 3. You can download from [here](https://www.python.org/downloads/). 

# Installation #
BOT PROTECT PY3 ANTI JS V2 LINE🐦FIXS UPDATE 19 AGUSTUS 2018
------
GET TOKEN :
------
- `Google Chrome`
- `http://101.255.95.249:6969`
-
Cara Install Bot :
------
HEADER CHROME

C9 SERVER/ VPS :
- `sudo apt-get update -y`
- `sudo apt-get install git -y`
- `sudo apt-get install python3-pip -y`
- `sudo pip3 install rsa`
- `sudo pip3 install thrift==0.11.0`
- `sudo pip3 install requests`
- `sudo pip3 install pytz`
- `sudo pip3 install bs4`
- `sudo pip3 install gtts`
- `sudo pip3 install googletrans`
- `sudo pip3 install humanfriendly`
- `sudo pip3 install goslate`
- `sudo pip3 install pafy`
- `sudo pip3 install wikipedia`
- `sudo pip3 install tweepy`
- `sudo pip3 install youtube_dl`
- `git clone https://github.com/arifistifik/ajs2`
- `cd ajs2`
- `python ajs.py`

INSTALL Di TERMUX :
- `pkg update`
- `pkg install git`
- `pkg install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install beautifulsoup`
- `pip3 install googletrans`
- `pip3 install pafy`
- `pip3 install humanfriendly`
- `pip3 install goslate`
- `pip3 install wikipedia`
- `pip3 install youtube_dl`
- `pip3 install tweepy`
- `git clone https://github.com/arifistifik/ajs2`
- `cd ajs2`
- `python3 ajs.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- `cd ajs2`
- `python3 ajs.py`

Di Termux :
- `cd ajs2`
- `python3 ajs.py`


EDITOR BY ARIFISTIFIK
------
- `Add My ID LINE : ngak punya line😂`

# ![logo](/dpksquare.png)LINE SQUARE
 
DPK SQUARE / [@DPKSQUARECHATBOT](https://line.me/ti/g2/AYYVNCU4U0)
------
Thx To : ALLOH SWT & All
------
- `SALAM HORMAT BUAT PARA MASTAH SEMUANYA 😅 `


